#-*-coding:utf-8-*-
import numpy as np
from os.path import dirname
import joblib
import sys
estimator_XGB =joblib.load(dirname(__file__) + "/models_of_14i/" + "/XGB/"+"my_lr_0.5832037467503137.pkl")
### plot feature importance
import matplotlib.pyplot as plt
from xgboost import plot_importance
#14feaures
# estimator_XGB._Booster.feature_names = ['gccount',  'Distance.to.TSS',  'Dnase',  'H2AFZ_broad',
#      'H3K4me3_merge',  'H3K4me1_usc', 'H3K4me2_broad','H3K9ac_merge',
#     'H4K20me1_broad','H3K27ac_broad','H3K36me3_merge', 'H3K79me2_broad','H3K9me3_broad','H3K27me3_usc',]
#
# fig,ax = plt.subplots(figsize=(10,5))
#
# plot_importance(estimator_XGB,
#                 height=0.5,
#                 ax=ax,
#                 importance_type="gain")
# plt.show()

importance = estimator_XGB.feature_importances_
estimator_XGB._Booster.feature_names = ['gccount',  'Distance.to.TSS',  'Dnase',  'H2AFZ_broad',
     'H3K4me3_merge',  'H3K4me1_usc', 'H3K4me2_broad','H3K9ac_merge',
    'H4K20me1_broad','H3K27ac_broad','H3K36me3_merge', 'H3K79me2_broad','H3K9me3_broad','H3K27me3_usc',]
feature_name = estimator_XGB._Booster.feature_names
import pandas as pd
# for (feature_name,importance) in zip(feature_name,importance):
#     print (feature_name,importance)
feature_importance = pd.DataFrame({'feature_name': feature_name, 'importance': importance})
feature_importance.to_csv('14feature_importance_XGB.csv', index=False)
print(feature_importance)