#-*-coding:utf-8-*-
import sys

#user_train = sys.argv[1]
print("chr22,39916226,39916325,+")