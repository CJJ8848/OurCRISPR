#14features predict (for java)
import numpy as np
from os.path import dirname
import joblib
import sys
# #predict with the trained model
user_train = sys.argv[1]

#print(str(user_train)+"fffff")
from sklearn.preprocessing import StandardScaler, MinMaxScaler

#user_train = "-0.991226,-2,-2,-0.275724,0.146128,-0.309804,-0.508638,0.693727,1.00647,T C G C G T A T G A A T C T C C T G G A C C"
#print(list(map(float,user_train.split(","))))
user_array = np.array(list(user_train.split(",")))

user_array = np.array(list(map(float,user_array[0:9])))

#print(user_array.reshape(1,-1))
## 3) 标准化z-score
#transfer = StandardScaler()
#user_array = transfer.fit_transform(user_array[:, np.newaxis])
estimator_Bag =joblib.load(dirname(__file__) + "/models_of_9i/" + "/Bag/" +"my_lr_0.5831430329596328.pkl")
estimator_Ext =joblib.load(dirname(__file__) + "/models_of_9i/" + "/Ext/" +"my_lr_0.7841793251906765.pkl")
estimator_Ran =joblib.load(dirname(__file__) + "/models_of_9i/" + "/Ran/"+"my_lr_0.502798350218223.pkl")
estimator_XGB =joblib.load(dirname(__file__) + "/models_of_9i/" + "/XGB/"+"my_lr_0.39534064797189533.pkl")

y_predict_Ran = estimator_Ran.predict(user_array.reshape(1,-1))[0]
print(str(y_predict_Ran))
y_predict_XGB = estimator_XGB.predict(user_array.reshape(1,-1))[0]
print(str(y_predict_XGB))
y_predict_Bag = estimator_Bag.predict(user_array.reshape(1,-1))[0]
print(str(y_predict_Bag))
y_predict_Ext = estimator_Ext.predict(user_array.reshape(1,-1))[0]
print(str(y_predict_Ext))
y_predict = [y_predict_Ran,y_predict_XGB,y_predict_Bag,y_predict_Ext]
print(sum(y_predict)/len(y_predict))