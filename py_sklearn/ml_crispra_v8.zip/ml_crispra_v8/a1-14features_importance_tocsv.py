#-*-coding:utf-8-*-
import numpy as np
from os.path import dirname
import joblib
import sys
estimator_Ext =joblib.load(dirname(__file__) + "/models_of_human/" + "/Ext/" +"my_lr_0.8407642870025351.pkl")
estimator_Ran =joblib.load(dirname(__file__) + "/models_of_human/" + "/Ran/"+"my_lr_0.869059509141587.pkl")
estimator_XGB =joblib.load(dirname(__file__) + "/models_of_human/" + "/XGB/"+"my_lr_0.839065308197502.pkl")


importance = estimator_Ran.feature_importances_
estimator_Ran.feature_names = ['gccount',  'Distance.to.TSS',  'Dnase',  'H2AFZ',
     'H3K4me3',  'H3K4me1', 'H3K4me2','H3K9ac',
    'H4K20me1','H3K27ac','H3K36me3', 'H3K79me2','H3K9me3','H3K27me3',]
feature_name = estimator_Ran.feature_names
import pandas as pd
# for (feature_name,importance) in zip(feature_name,importance):
#     print (feature_name,importance)
feature_importance = pd.DataFrame({'feature_name': feature_name, 'importance': importance})
#要改一下名字
feature_importance.to_csv('a14feature_importance_Ran.csv', index=False)
print(feature_importance)