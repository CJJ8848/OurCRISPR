library(readr)
library(ggplot2)
##10features
#14features
#9features
#df <- read_csv("Desktop/SRTP/python/ml_crispra_v6/featureimportance_csv/a10feature_importance_ Ext XGB Ran .csv")
#df <- read_csv("Desktop/SRTP/python/ml_crispra_v6/featureimportance_csv/i10feature_importance_Ran.csv")
#df <- read_csv("Desktop/SRTP/python/ml_crispra_v6/featureimportance_csv/a10feature_importance_XGB.csv")
df <- read_csv("Desktop/SRTP/python/ml_crispra_v6/featureimportance_csv/i9feature_importance_Ran.csv")#换

df<-df[sort(-df$importance,index.return=TRUE)$ix,]
names(df)[names(df) == 'feature_name'] <- 'features'
a10ext<-ggplot(data=df, aes(x=features<- reorder(features,importance), y=importance)) +
  ylim(0,max(df$importance)+0.2)+
  geom_bar(stat="identity") +labs(title = "Ran model/9 features/crispri")+#换
   geom_text(aes(label = importance), size = 3,hjust = -0.1)+
  coord_flip()
a10ext
#ggsave(a10ext, file='/Users/cuijiajun/Desktop/SRTP/python/ml_crispra_v6/plots_feature_importance/a10Ext.png', width=8, height=6)
#ggsave(a10ext, file='/Users/cuijiajun/Desktop/SRTP/python/ml_crispra_v6/plots_feature_importance/i10XRan.png', width=8, height=6)
#ggsave(a10ext, file='/Users/cuijiajun/Desktop/SRTP/python/ml_crispra_v6/plots_feature_importance/a10XGB.png', width=8, height=6)
ggsave(a10ext, file='/Users/cuijiajun/Desktop/SRTP/python/ml_crispra_v6/plots_feature_importance/i9Ran.png', width=8, height=6)#huan



