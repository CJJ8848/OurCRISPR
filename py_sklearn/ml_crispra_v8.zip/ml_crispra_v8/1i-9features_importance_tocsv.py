#-*-coding:utf-8-*-
import numpy as np
from os.path import dirname
import joblib
import sys
estimator_Ext =joblib.load(dirname(__file__) + "/models_of_9i/" + "/Ext/" +"my_lr_0.7841793251906765.pkl")
estimator_Ran =joblib.load(dirname(__file__) + "/models_of_9i/" + "/Ran/"+"my_lr_0.502798350218223.pkl")
estimator_XGB =joblib.load(dirname(__file__) + "/models_of_9i/" + "/XGB/"+"my_lr_0.39534064797189533.pkl")

importance = estimator_XGB.feature_importances_
estimator_XGB.feature_names = ['gc_content',  'Distance.to.TSS',  'K562_H3K4me3',  'K562_H3K4me1',
     'K562_H3K9ac',  'K562_H3K27ac', 'K562_H3K36me3','K562_H3K9me3',
    'K562_H3K27me3',]
feature_name = estimator_XGB.feature_names
import pandas as pd
# for (feature_name,importance) in zip(feature_name,importance):
#     print (feature_name,importance)
feature_importance = pd.DataFrame({'feature_name': feature_name, 'importance': importance})
#要改一下名字
feature_importance.to_csv('i9feature_importance_XGB.csv', index=False)
print(feature_importance)