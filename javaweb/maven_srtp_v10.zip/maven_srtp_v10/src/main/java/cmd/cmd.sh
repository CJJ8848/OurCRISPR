'cd /media/jiahui/hdd2/srtp2018/ && ./pipeline_final.sh' $1 $2 $3 $4 $5 $6
