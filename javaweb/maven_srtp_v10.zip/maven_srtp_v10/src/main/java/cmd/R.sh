Rscript /Users/cuijiajun/Desktop/plot3.R $1 $2 $3 $4 $5 $6
