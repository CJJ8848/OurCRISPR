package servlet;

import service.getR;
import service.get_remote_py;
import service.get_remote_sh;
import service.getpy;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

@WebServlet("/ih_score_result")
public class crispri_h_score_result_py_servlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        getpy getpy = new getpy();
        get_remote_sh get_remote_sh = new get_remote_sh();
        getR getR = new getR();
        String strinput = null;
        String genome = (String) session.getAttribute("genome");
        String cellline = (String) session.getAttribute("cellline");
        String site = (String) session.getAttribute("site");
        String designer = (String) session.getAttribute("designer");
        System.out.println(site);
        if (Pattern.compile("designer").matcher(designer).find()) {
            System.out.println("designerrrrrrr");
            if (Pattern.compile("^\\w{1,}.*?,chr.*?,\\d{1,}.*?,\\d{1,}.*?,\\+.*?", Pattern.MULTILINE).matcher(site).find() | Pattern.compile("^\\w{1,}.*?,chr\\d{1,}.*?,\\d{1,}.*?,\\d{1,}.*?,-.*?", Pattern.MULTILINE).matcher(site).find()) {
                List<String> sitelist = Arrays.asList(site.split("\n"));


                for (int i = 0; i < sitelist.size(); i++) {
                    String siteitem = sitelist.get(i);
                    List<String> sitesingle = Arrays.asList(siteitem.split(","));
                    String genedesign = sitesingle.get(0);
                    String chromdesign = sitesingle.get(1);
                    String startdesign = sitesingle.get(2);
                    String enddesign = sitesingle.get(3);

                    try {
                        //designer input designtext output sgrna strbydesignsingle
                        //-i mm39 -g name,chrom,start,end\nNfib,chr4,82208410,82208500
                        String designtext = "-i" + " " + genome + " " + "-g" + " " + "name,chrom,start,end\\\\n" + genedesign + "," + chromdesign + "," + startdesign + "," + enddesign;
                        System.out.println(designtext);
                        String strbydesignall = get_remote_py.getPythonDemo(" design_library_v3.py", designtext);
//                        String strbydesignall = "..............................................................................................................................................................................................................................................\n" +
//                                "average search steps:1.30728 maximum search steps:3\n" +
//                                "3137161264 base pairs processed. average search speed: 4.75076e+06 bps/sec.\n" +
//                                "time used: 671.95 seconds\n" +
//                                "chrX,48645004,48645024,- " +
//                                "chrX,48644973,48644993,+ " +
//                                "chrX,48644922,48644942,+";
                        List<String> strbydesigns = Arrays.asList(strbydesignall.split("seconds"));
                        String strbydesign = strbydesigns.get(strbydesigns.size()-1);
                        System.out.println("results:"+strbydesign);
                        List<String> sgrnalist = Arrays.asList(strbydesign.split(" "));
                        System.out.println("get1 "+sgrnalist.get(1));//第一个
                        List<List> sgnextlinelist = new ArrayList<>();
                        for (int j = 1; j < sgrnalist.size(); j++) {
                            String sgrnaitem = sgrnalist.get(j);
                            List<String> strbydesignsingle = Arrays.asList(sgrnaitem.replaceAll("\\[", "").split(","));
                            System.out.println(strbydesignsingle);
                            String chrom = strbydesignsingle.get(0);
                            String start = strbydesignsingle.get(1);
                            String end = strbydesignsingle.get(2);
                            String sgstrand = strbydesignsingle.get(3);
                            strinput = get_remote_sh.getsh_demo(genome, cellline, chrom, start, end, sgstrand);
                            request.setAttribute("start", start);
                            String str = getpy.getPythonDemo("/Users/cuijiajun/Desktop/SRTP/python/ml_crispra_v6/ml_crispra_14features_model.py", strinput);
                            System.out.println("python" + str);
                            str = str + "," + chrom + "," + start + "," + end + "," + sgstrand + "," + strinput;
                            str = str.replaceAll(" ", "");
                            List<String> lt = Arrays.asList(str.replaceAll("\\[|\\]", "").split(","));
//                           List<String> featurevalues = Arrays.asList(strinput.replaceAll("\\[|\\]", "").split(","));
                            try {
                                getR.getR_demo("/Users/cuijiajun/Desktop/plot3.R", lt.get(0), lt.get(1), lt.get(2), lt.get(3), lt.get(4), start);
                                System.out.println("R" + lt);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            sgnextlinelist.add(lt);
                        }
                        List<List> nextlinelist = sgnextlinelist;


                        String feature = "gccount\tDistance.to.TSS\tDnase\tH2AFZ_broad\tH3K4me3_merge\tH3K4me1_usc\tH3K4me2_broad\tH3K9ac_merge\tH4K20me1_broad\tH3K27ac_broad\tH3K36me3_merge\tH3K79me2_broad\tH3K9me3_broad\tH3K27me3_usc";
                        List<String> features = Arrays.asList(feature.replaceAll("\\[|\\]", "").split("\t"));
                        request.setAttribute("features", features);
                        request.setAttribute("nextlinelist", nextlinelist);
                        request.setAttribute("species", "Human");
                        request.setAttribute("crispr", "i");
                        //            request.setAttribute("featurevalues",featurevalues);
                        String plotpath = this.getServletContext().getRealPath("/plots");
                        System.out.println(plotpath);
                        request.setAttribute("path", plotpath);
                        if (Pattern.compile("unconvertableGenome").matcher(strinput).find()) {
                            request.setAttribute("liftover", null);
                            System.out.println("liftovernull");
                            request.getRequestDispatcher("/jsp/confirm_h.jsp").forward(request, response);
                        } else {
                            request.getRequestDispatcher("/jsp/score_result.jsp").forward(request, response);

                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } else {
                request.getRequestDispatcher("/jsp/homepage_a.jsp").forward(request, response);
            }
        }
        else {
            if (Pattern.compile("^chr.*?,\\d{1,}.*?,\\d{1,}.*?,\\+.*?", Pattern.MULTILINE).matcher(site).find() | Pattern.compile("^chr\\d{1,}.*?,\\d{1,}.*?,\\d{1,}.*?,-.*?", Pattern.MULTILINE).matcher(site).find()) {
                List<String> sitelist = Arrays.asList(site.split("\n"));
                List<List> nextlinelist = new ArrayList<>();


                for (int i = 0; i < sitelist.size(); i++) {
                    String siteitem = sitelist.get(i);
                    List<String> sitesingle = Arrays.asList(siteitem.split(","));
                    String chrom = sitesingle.get(0);
                    String start = sitesingle.get(1);
                    String end = sitesingle.get(2);
                    String strand = sitesingle.get(3);

                    try {
                        strinput = get_remote_sh.getsh_demo(genome, cellline, chrom, start, end, strand);
                        request.setAttribute("start", start);
                        String str = getpy.getPythonDemo("/Users/cuijiajun/Desktop/SRTP/python/ml_crispra_v6/ml_crispri_14features_model.py", strinput);
                        System.out.println("python" + str);
                        str = str + "," + siteitem + "," + strinput;
                        str = str.replaceAll(" ", "");
                        List<String> lt = Arrays.asList(str.replaceAll("\\[|\\]", "").split(","));
//                    List<String> featurevalues = Arrays.asList(strinput.replaceAll("\\[|\\]", "").split(","));
                        try {
                            getR.getR_demo("/Users/cuijiajun/Desktop/plot3.R", lt.get(0), lt.get(1), lt.get(2), lt.get(3), lt.get(4), start);
                            System.out.println("R" + lt);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        nextlinelist.add(lt);


                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                }
                String feature = "gccount\tDistance.to.TSS\tDnase\tH2AFZ_broad\tH3K4me3_merge\tH3K4me1_usc\tH3K4me2_broad\tH3K9ac_merge\tH4K20me1_broad\tH3K27ac_broad\tH3K36me3_merge\tH3K79me2_broad\tH3K9me3_broad\tH3K27me3_usc";
                List<String> features = Arrays.asList(feature.replaceAll("\\[|\\]", "").split("\t"));
                request.setAttribute("features", features);
                request.setAttribute("nextlinelist", nextlinelist);
                request.setAttribute("species", "Human");
                request.setAttribute("crispr", "i");
//            request.setAttribute("featurevalues",featurevalues);
                String plotpath = this.getServletContext().getRealPath("/plots");
                System.out.println(plotpath);
                request.setAttribute("path", plotpath);
                if (Pattern.compile("unconvertableGenome").matcher(strinput).find()) {
                    request.setAttribute("liftover", null);
                    System.out.println("liftovernull");
                    request.getRequestDispatcher("/jsp/confirm_h.jsp").forward(request, response);
                } else {
                    request.getRequestDispatcher("/jsp/score_result.jsp").forward(request, response);

                }

            } else {
                request.getRequestDispatcher("/jsp/homepage_i.jsp").forward(request, response);
            }

        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
