package servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.regex.Pattern;

@WebServlet("/im_info")
public class crispri_m_info_servlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String genome = request.getParameter("genome");
        String cellline = request.getParameter("cellline");
        String site = request.getParameter("site");
        HttpSession session = request.getSession();
        session.setAttribute("mgenome",genome);
        session.setAttribute("mcellline",cellline);
        session.setAttribute("msite",site);
        session.setAttribute("liftover","init");
        session.setAttribute("crispra",null);
        String designer = request.getParameter("designer");
        session.setAttribute("designer",designer);
        String text = site;
        String filter = null;
        String designfilter = null;
        if (Pattern.compile("designer").matcher(designer).find()){
            designfilter = "success";
            session.setAttribute("designfilter", designfilter);
            if (Pattern.compile("^\\w{1,}.*?,chr.*?,\\d{1,}.*?,\\d{1,}.*?,\\+.*?",Pattern.MULTILINE).matcher(site).find() | Pattern.compile("^\\w{1,}.*?,chr\\d{1,}.*?,\\d{1,}.*?,\\d{1,}.*?,-.*?",Pattern.MULTILINE).matcher(site).find()) {
                filter = "success";
                session.setAttribute("filter", filter);
            } else {
                filter = null;
                session.setAttribute("filter", null);
            }
            request.getRequestDispatcher("jsp/confirm_m.jsp").forward(request, response);
        }
        else {
            session.setAttribute("designfilter", null);
            if (Pattern.compile("^chr.*?,\\d{1,}.*?,\\d{1,}.*?,\\+.*?",Pattern.MULTILINE).matcher(site).find() | Pattern.compile("^chr\\d{1,}.*?,\\d{1,}.*?,\\d{1,}.*?,-.*?",Pattern.MULTILINE).matcher(site).find()) {
                filter = "success";
                session.setAttribute("filter", filter);

            } else {
                filter = null;
                session.setAttribute("filter", null);
            }
            request.getRequestDispatcher("jsp/confirm_m.jsp").forward(request, response);
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
