package service;

import com.jcraft.jsch.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;


public class get_remote_sh {
    private static Session session;

    private static boolean connect(String username, String ip, String password) {
        JSch jsch = new JSch();
        try {
            session = jsch.getSession(username, ip, 22);
            session.setPassword(password);
            Properties config = new Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            session.connect();
            System.out.println("connect success");
        } catch (JSchException e) {
            e.printStackTrace();
            System.out.println("connect fail !");
            return false;
        }
        return true;
    }
    public static String runRemoteShell(String username, String ip, String password, String command) throws Exception {
        if (session == null) {
            if (!connect(username, ip, password)) {
                return null;
            }
        }
        BufferedReader reader = null;
        Channel channel = null;
        String str = "";
        try {
            channel = session.openChannel("exec");
            ((ChannelExec) channel).setCommand(command);

            channel.setInputStream(null);
            ((ChannelExec) channel).setErrStream(System.err);

            channel.connect();
            InputStream in = channel.getInputStream();
            reader = new BufferedReader(new InputStreamReader(in));
            String buf;
            while ((buf = reader.readLine()) != null) {
                if (buf.contains("PID")) {
                    break;
                }
                System.out.println("buf:"+buf);
                str += buf.trim() + " ";
            }
        } catch (IOException | JSchException e) {
            e.printStackTrace();
            throw e;
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
                if (channel != null) {
                    channel.disconnect();
                }
                session.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return str;
    }
        public static String getsh_demo(String genome, String cellline, String chrom, String start, String end, String strand) throws Exception {
        connect("jiahui","10.109.92.2","1433997922Bb");
        String strsh = genome+" "+cellline+" "+chrom+" "+start+" "+end+" "+strand;
        System.out.println(strsh);
        String result = runRemoteShell("jiahui","10.109.92.2","1433997922Bb","cd /media/jiahui/hdd2/srtp2018/ && ./pipeline_final.sh"+" "+strsh);
        return result;
    }
}
